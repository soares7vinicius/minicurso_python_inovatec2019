a = float(input())
b = float(input())
print('MEDIA = {0:.5f}'.format((a*3.5+b*7.5)/(3.5+7.5)))